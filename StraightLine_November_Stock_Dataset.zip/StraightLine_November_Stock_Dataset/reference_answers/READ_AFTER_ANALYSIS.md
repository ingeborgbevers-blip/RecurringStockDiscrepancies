# Reference answers: designed scenarios

Open after investigating the raw data. These are generation rules and validation controls, not independent proof about real businesses.

- ITM001-003: Wednesday case receipts use factor 1 in the system instead of item-specific CASE conversion in 11 of 12 cycles. Cycle 8 is clean; there is no implemented intervention or causal improvement claim. Expect positive reserve variances and positive residual adjustments.
- ITM004-006: selected Tuesday transfers go physically to PICK-A but are credited to HOLD-A in the ledger. Cycles 4, 8 and 12 are clean. Expect offsetting bin differences and zero net item variance across the warehouse. Both sides need a location correction.
- ITM007-009: Friday dispatches post on the following Monday in eight cycles. Every third cycle is clean. Expect negative picking variance at count, explained by a later negative ledger posting before review, with no residual adjustment for that timing difference.
- ITM010-011: small damage removals every third cycle starting with cycle 1 have a physical task but no ledger movement. Expect genuine physical reductions and negative residual adjustments. Their standard-cost effect is illustrative, not an actual client loss.
- Some first counts contain small mistakes. Recounts replace them before approval; do not use first counts as final observations.
- Remaining products and other bins serve as controls with accurate accepted counts and correctly posted operations. Ordinary correct transfers and CASE receipts also exist, so neither category alone identifies an error.

Scenario_Records.csv supplies task/count references and a bridge for every count. Filter record_type=count_bridge for: raw_variance_each = late_posting_qty_each + approved_adjustment_qty_each. Missing numeric fields on other record types are not zero-valued bridge records.

Validation_Report.json provides row counts and completed checks. No random losses, unexplained stock differences or invented customer outcomes have been added.
