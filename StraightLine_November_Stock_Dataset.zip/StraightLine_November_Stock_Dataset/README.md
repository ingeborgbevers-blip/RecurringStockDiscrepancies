# Recurring stock discrepancies

Synthetic dataset created for StraightLine Data & Training's November 2026 portfolio work. All businesses, items, quantities, costs and people are fictional. These are designed scenarios, not empirical evidence about real businesses or measured results of an intervention. You may adapt and publish this dataset with a clear synthetic-data label.

## Start here

Open Stock_Discrepancies.xlsx to explore the tables, or import the CSVs in data/ into Power BI, PostgreSQL or Excel. The workbook and CSVs contain the same raw values. No dashboard or analysis answers are embedded. Data_Dictionary.csv explains every raw field. Keep reference_answers/ out of your analytical model until you want to check the designed scenarios.

One warehouse, 24 products, three bins, 12 weekly full counts. Physical activity covers 3 August to 23 October 2026. Final count review is 26 October, with an extract as of 09:00 that morning. There are no future or live observations. Timestamps are timezone-free local warehouse times (Europe/London); no activity occurs during the clock-change hour.

## Suggested two-week investigation

Week 1: derive accepted count minus frozen system quantity. Compare frequency and absolute standard-cost exposure by item, bin and cycle. Include accurate counts in denominators. Determine which discrepancies recur and which disappear at warehouse level when bins are combined.

Week 2: match source tasks to system movements by task_id; compare physical and posted bins, document units, reference conversion and posting times. Reconcile each discrepancy before suggesting an action. Show one operational question and one practical next step per evidenced pattern. No before/after intervention period is included.

## Model and grain

Products: one row per item. Bins: one row per location. UOM: one row per item/unit pair. OpeningStock: one row per item/bin. WarehouseTasks: one row per completed physical task. StockLedger: one row per posted system movement line. CountCycles: one row per weekly cycle. StockCounts: one row per item/bin/cycle. Adjustments: one row per nonzero approved residual count adjustment.

Use Products and Bins as shared one-to-many dimensions. Join CountCycles to StockCounts by cycle_id. UOM needs a composite item_id + uom key. Task-to-ledger is one-to-many; do not join and sum handled_qty_each without accounting for transfer duplication. Count-to-adjustment is zero-or-one. Adjustment movement_id identifies a line already present in StockLedger; never append Adjustments as extra ledger movements. Prefer dimensions and separate facts rather than one flattened table.

## Time and reconciliation rules

Opening balances are correct physical and system balances at 3 August 00:00. System balance at a historical cutoff is opening quantity plus signed_qty_each for ledger rows with posted_at <= cutoff. Use posted_at, not event_at, to reproduce frozen system snapshots.

Physical balance is opening quantity plus completed receipts and transfers in, less dispatches, damage removals and transfers out, by event_at. Tasks are complete physical observations for this fictional exercise, not an ERP ledger.

All bins are counted Friday at 17:00. Physical movement is frozen until review on Monday at 08:30. Late system postings are permitted during that freeze. Approved adjustment = accepted count - (frozen system quantity + net ledger postings after count and up to review). Only residual differences are adjusted. This prevents timing differences being corrected twice. Later-cycle stock includes previous adjustments.

Use recount_qty_each when present, including a legitimate zero; otherwise use first_count_qty_each. Blank recount means no recount. The accepted count is supplied so you can validate that rule.

## Definitions and interpretation

Variance each = accepted_count_qty_each - system_qty_at_count_each. Positive means counted stock exceeds book stock. Net standard-cost variance = variance each x standard_unit_cost_gbp. Absolute exposure = ABS(variance each) x standard_unit_cost_gbp. These are illustrative standard-cost measures, not realised losses, recoveries or savings.

Summing absolute bin variances can count both sides of a mislocation. Compare bin-level exposure with warehouse-level item variance. Never add stock balances over dates as if they were flows. Count snapshots are not extra ledger movements.

Recurrence can be counted as distinct discrepant cycles per item or item/bin, using all 12 observed cycles as the denominator. A zero warehouse net does not mean the picking-location problem has no operational consequence. No financial materiality threshold is supplied; label any threshold you choose.

No actual SAP database export or SAP table schema is represented. No batch, serial, expiry, tax, sales or service-level model is included. Generic adjustment reason codes deliberately do not reveal underlying causes.
